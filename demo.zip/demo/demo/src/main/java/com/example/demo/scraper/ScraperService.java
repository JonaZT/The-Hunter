package com.example.demo.scraper;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

@Service
public class ScraperService {

    public List<VacanteRaw> scrapeOCC() {
        List<VacanteRaw> vacantes = new ArrayList<>();
        WebDriver driver = crearDriver();

        try {
            driver.get("https://www.occ.com.mx/empleos/de-ingeniero-software/?ubicacion=tijuana-baja-california");

            WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
            wait.until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector("div[data-id]")
            ));

            // Agarramos cada tarjeta completa por su data-id
            List<WebElement> tarjetas = driver.findElements(
                    By.cssSelector("div[data-id][id^='jobcard-']")
            );

            System.out.println("📋 Tarjetas encontradas: " + tarjetas.size());

            for (WebElement tarjeta : tarjetas) {
                // Extraer data-id del div contenedor
                String dataId = tarjeta.getAttribute("data-id");

                // Extraer título con el selector exacto que inspeccionaste
                String titulo = "";
                try {
                    WebElement h2 = tarjeta.findElement(By.cssSelector("h2.text-grey-900"));
                    titulo = h2.getText().trim();
                } catch (NoSuchElementException e) {
                    continue; // tarjeta sin título, la saltamos
                }

                // Extraer salario (puede no existir)
                String salario = "";
                try {
                    WebElement salarioEl = tarjeta.findElement(By.cssSelector("span.font-light.mb-2, span.font-light.sm\\:mb-4"));
                    salario = salarioEl.getText().trim();
                } catch (NoSuchElementException e) {
                    salario = "No especificado";
                }

                // Extraer empresa
                String empresa = "";
                try {
                    WebElement empresaEl = tarjeta.findElement(By.cssSelector("a[href*='/empleos/bolsa-de-trabajo']"));
                    empresa = empresaEl.getText().trim();
                } catch (NoSuchElementException e) {
                    empresa = "No especificada";
                }

                // Extraer ubicación
                String ubicacion = "";
                try {
                    WebElement ubicacionEl = tarjeta.findElement(By.cssSelector("p.text-grey-900.text-sm"));
                    ubicacion = ubicacionEl.getText().trim();
                } catch (NoSuchElementException e) {
                    ubicacion = "No especificada";
                }

                // Construir URL con el data-id
                String url = "https://www.occ.com.mx/empleo/" + dataId + "/";

                if (!titulo.isEmpty() && dataId != null) {
                    VacanteRaw v = new VacanteRaw(titulo, url, salario, empresa, ubicacion, dataId);
                    vacantes.add(v);

                    System.out.println("─────────────────────────────");
                    System.out.println("  📌 " + titulo);
                    System.out.println("  🏢 " + empresa);
                    System.out.println("  📍 " + ubicacion);
                    System.out.println("  💰 " + salario);
                    System.out.println("  🔗 " + url);
                }
            }

        } catch (TimeoutException e) {
            System.out.println("⏱ Timeout esperando tarjetas");
        } catch (Exception e) {
            System.out.println("❌ Error: " + e.getMessage());
        } finally {
            driver.quit();
        }

        return vacantes;
    }

    private WebDriver crearDriver() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--disable-blink-features=AutomationControlled");
        options.addArguments("--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36");
        options.setExperimentalOption("excludeSwitches", List.of("enable-automation"));
        return new ChromeDriver(options);
    }

    public record VacanteRaw(
            String titulo,
            String url,
            String salario,
            String empresa,
            String ubicacion,
            String externalId   // el data-id de OCC — clave para detectar duplicados
    ) {}
}
