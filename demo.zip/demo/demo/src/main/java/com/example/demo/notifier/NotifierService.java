package com.example.demo.notifier;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@Service
public class NotifierService {

    @Value("${telegram.bot.token}")
    private String token;

    @Value("${telegram.bot.chatId}")
    private String chatId;

    private final RestTemplate restTemplate = new RestTemplate();

    public void enviar(String titulo, String empresa, String ubicacion,
                       String salario, String url) {
        String mensaje = String.format("🎯 *Nueva vacante encontrada*\n\n📌 *%s*\n🏢 %s\n📍 %s\n💰 %s\n🔗 %s",
                codificarParaURL(titulo),
                codificarParaURL(empresa),
                codificarParaURL(ubicacion),
                codificarParaURL(salario),
                codificarParaURL(url));

        String apiUrl = String.format(
                "https://api.telegram.org/bot%s/sendMessage?chat_id=%s&text=%s&parse_mode=Markdown",
                token, chatId,
                mensaje.replace(" ", "%20")
                        .replace("\n", "%0A")
                        .replace("*", "%2A")
        );



        try {
            String response = restTemplate.getForObject(apiUrl, String.class);
            System.out.println("📨 Telegram enviado: " + titulo);
        } catch (Exception e) {
            System.out.println("❌ Error Telegram: " + e.getMessage());
        }
    }
    public String codificarParaURL(String texto) {
        return URLEncoder.encode(texto, StandardCharsets.UTF_8);
    }
}