package com.example.demo;

import com.example.demo.filter.FilterEngine;
import com.example.demo.model.Vacante;
import com.example.demo.repository.VacanteRepository;
import com.example.demo.scraper.ScraperService;
import com.example.demo.scraper.ScraperService.VacanteRaw;
import org.springframework.boot.SpringApplication;
import org.springframework.context.ApplicationContext;

import java.util.List;

public class prueba {

    public static void main(String[] args) {

        // Levantar el contexto completo de Spring
        ApplicationContext ctx = SpringApplication.run(DemoApplication.class, args);

        ScraperService scraper       = ctx.getBean(ScraperService.class);
        FilterEngine   filter        = ctx.getBean(FilterEngine.class);
        VacanteRepository repository = ctx.getBean(VacanteRepository.class);

        // 1. Scrape + filtro
        List<VacanteRaw> filtradas = filter.filtrar(scraper.scrapeOCC());
        System.out.println("\n✅ Vacantes filtradas: " + filtradas.size());

        // 2. Guardar solo las nuevas
        int nuevas = 0;
        int duplicadas = 0;

        for (VacanteRaw raw : filtradas) {
            if (repository.existsByExternalId(raw.externalId())) {
                System.out.println("⏭ Ya existe: " + raw.titulo());
                duplicadas++;
            } else {
                Vacante v = new Vacante(
                        raw.externalId(),
                        filter.limpiar(raw.titulo()),
                        filter.limpiar(raw.empresa()),
                        raw.ubicacion(),
                        raw.salario(),
                        raw.url()
                );
                repository.save(v);
                System.out.println("💾 Guardada nueva: " + v.getTitulo());
                nuevas++;
            }
        }

        System.out.println("\n─────────────────────────────");
        System.out.println("💾 Nuevas guardadas : " + nuevas);
        System.out.println("⏭ Duplicadas        : " + duplicadas);
        System.out.println("📦 Total en DB      : " + repository.count());

        // 3. Correr dos veces para confirmar que no duplica
        System.out.println("\n🔁 Segunda pasada (simulando re-ejecución)...");
        int duplicadasSegundaPasada = 0;
        for (VacanteRaw raw : filtradas) {
            if (repository.existsByExternalId(raw.externalId())) {
                System.out.println("⏭ Duplicado detectado correctamente: " + raw.titulo());
                duplicadasSegundaPasada++;
            }
        }
        System.out.println("✅ Duplicados en segunda pasada: " + duplicadasSegundaPasada + "/" + filtradas.size());
    }
}